package com.team1.cityfarm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityfarmApplicationTests {

    @Test
    void contextLoads() {
    }

}
